
#include<stdio.h>
#include<math.h>
#define M 100                                     /*�������*/
#define N 100                                     /*��������*/
int i,j,k,a,b,c;                                  /*ѭ�����Ʊ���*/ 
int t,l,g;                                        /*�м����*/            
int n,                                            /* �ڵ��� */
    m,                                            /* ֧·�� */
    pq,                                           /* PQ�ڵ��� */
    pv;                                           /* PV�ڵ��� */
    duidi;                                        /*�Ե�֧·��*/
	K;                                            /*���*/
    
double eps;                                       /* ���� */
double AA[M],BB[M],CC[M],DD[M],max,temp, rr,tt;   /*�м����*/           
double mo,c1,d1,c2,d2,jiao;                       /*�������㺯���ķ���ֵ*/   
double G[M][M],B[M][M],Y[M][M];                   /*�ڵ㵼�ɾ����е�ʵ�����鲿����ģ��ֵ*/
double ykb[M][M],D[M],dU[M];                      /*�ſ˱Ⱦ��󡢲�ƽ��������*/
	     
struct jd                                         /* �ڵ�ṹ�� */
      {  int num,s;                               /* numΪ�ڵ�ţ�sΪ�ڵ�����*/
	     double p,q,e,f,U,zkj,dp,dq,du,de,df;   /*�ڵ��й����޹����ʣ�����ģֵ����ѹ�ݡ����������ѹģֵ,�迹��
		                                                 ţ��--����ѷ�й��ʲ�ƽ��������ѹ��ƽ����*/
      } jd[M];

struct zhl                                /* ֧·�ṹ�� */
      {  int numb;                        /*numbΪ֧·��*/
	     int p1,p2;                       /*֧·�������ڵ�*/
	     double kx;                        /*���*/
		 double r,x;                      /*֧·�ĵ�����翹*/
         
} zhl[M];


FILE *fp1,*fp2;
void data()                           /* ��ȡ���� */
 { 
	int h,number;
    fp1=fopen("input.txt","r");if(fp1==NULL)
    { 
		printf(" can not open file !\n");
        exit(0);
    }
    fscanf(fp1,"%d,%d,%d,%d,%d,%lf\n",&n,&m,&pq,&pv,&duidi,&eps);              /*����ڵ���,֧·��,PQ�ڵ���,PV�ڵ����Ե�֧·�;���*/ 
	
    j=1;k=pq+1;
    for(i=1;i<=n;i++)                                                /*����ڵ��š����͡����빦�ʺ͵�ѹ��ֵ*/
    {
		fscanf(fp1,"%d,%d",&number,&h);
	    if(h==1)                                                     /*����h=1��PQ�ڵ�*/
		{ 
			fscanf(fp1,",%lf,%lf,%lf,%lf\n",&jd[j].p,&jd[j].q,&jd[j].e,&jd[j].f);
	        jd[j].num=number;
	        jd[j].s=h;
	        j++;
		}
	    if(h==2)                                                    /*����h=2��pv�ڵ�*/
		{
			fscanf(fp1,",%lf,%lf\n",&jd[k].p,&jd[k].U);
	        jd[k].num=number;
	        jd[k].s=h;
			jd[k].q=0.0;
	        k++;
		}
	   if(h==3)                                                    /*����h=3��ƽ��ڵ�*/
	   {
		   fscanf(fp1,",%lf,%lf\n",&jd[n].e,&jd[n].f);
	       jd[n].num=number;
	       jd[n].s=h;
	   }
	}
   for(i=1;i<=m;i++)                                               /*����֧·�迹*/
	   fscanf(fp1,"%d,%d,%d,%lf,%lf,%lf\n",&zhl[i].numb,&zhl[i].p1,&zhl[i].p2,&zhl[i].kx,&zhl[i].r,&zhl[i].x);	 
       fclose(fp1);
   if((fp2=fopen("output.txt","w"))==NULL)
   { 
	   printf("  can not open file!\n");
       exit(0);
   }


fprintf(fp2,"\n                                   �����ϻ�����\n                               ������0704  �Ų�200703020222\n");
  fprintf(fp2,"\n                         ********** ԭʼ���� *********\n");
  fprintf(fp2,"  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
  fprintf(fp2,"     �ڵ���:%d ֧·��:%d  PQ�ڵ���:%d  PV�ڵ���:%d  �Ե�֧·��:%d  ����:%f\n",
	  								 n,m,pq,pv,duidi,eps);
  fprintf(fp2,"  ------------------------------------------------------------------------------\n");
  for(i=1;i<=pq;i++)
  fprintf(fp2,"     PQ�ڵ�:      �ڵ�%d       P[%d]=%f    Q[%d]=%f\n",
	       jd[i].num,jd[i].num,jd[i].p,jd[i].num,jd[i].q);
  for(i=pq+1;i<=pq+pv;i++)
  fprintf(fp2,"     PV�ڵ�:      �ڵ�%d       P[%d]=%f     U[%d]=%f    ��ֵQ[%d]=%f\n",
	       jd[i].num,jd[i].num,jd[i].p,jd[i].num,jd[i].U,jd[i].num,jd[i].q);
  fprintf(fp2,"     ƽ��ڵ�:    �ڵ�%d       e[%d]= %f    f[%d]= %f\n",
	       jd[n].num,jd[n].num,jd[n].e,jd[n].num,jd[n].f);
  fprintf(fp2,"  -------------------------------------------------------------------------------\n");
  for(i=1;i<=m;i++)
  fprintf(fp2,"     ֧·%d:     ��ؽڵ�:%d,%d  ���:kx=%f R=%f  X=%f  \n",
		      i,zhl[i].p1,zhl[i].p2,zhl[i].kx,zhl[i].r,zhl[i].x);
  fprintf(fp2,"  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
} 

/*------------------------------------�������㺯��--------------------------------------*/
 double mozhi(double a0,double b0)                      /*������ģֵ����*/
 { 	 mo=sqrt(a0*a0+b0*b0);       } 
 double ji(double a1,double b1,double a2,double b2)     /*�����������*/
 {   c1=a1*a2-b1*b2;
	 d1=a1*b2+a2*b1;
 }
 double shang(double a3,double b3,double a4,double b4)  /*�������̺���*/
 {   c2=(a3*a4+b3*b4)/(a4*a4+b4*b4);
     d2=(a4*b3-a3*b4)/(a4*a4+b4*b4);
 }
 
 /*--------------------------------����ڵ㵼�ɾ���----------------------------------*/
 void Form_Y()
 {
	 for(i=1;i<=n;i++)                               /*�ڵ㵼�ɾ���Ԫ�ظ���ֵ*/
		 for(j=1;j<=n;j++)
			 G[i][j]=B[i][j]=0; 
                                                     /*�ڵ㵼�ɾ�������Խ����ϵ�Ԫ��*/
	 for(i=1;i<=m;i++)                               /*���Եص��ɼ�����Ӧ�����Խ���Ԫ����*/
	 {
		if((zhl[i].p1==0)||(zhl[i].p2==0))
		{
			mozhi(zhl[i].r,zhl[i].x);
            if(mo==0) 
			{
				G[zhl[i].p1][zhl[i].p2]=B[zhl[i].p1][zhl[i].p2]=G[zhl[i].p2][zhl[i].p1]=B[zhl[i].p2][zhl[i].p1]=0;
				continue;
			}
			shang(1,0,zhl[i].r,zhl[i].x);
			if(zhl[i].p1==0)
			{				
				G[zhl[i].p2][zhl[i].p2]+=c2;
            	B[zhl[i].p2][zhl[i].p2]+=d2;
			}
	        if(zhl[i].p2==0)
			{
				G[zhl[i].p1][zhl[i].p1]+=c2;
            	B[zhl[i].p1][zhl[i].p1]+=d2;
			}
		} 
	 }
	 for(i=1;i<=n;i++)                                /*�ǶԵص��ɼ�����Ӧ�����Խ���Ԫ����(���ǷǱ�׼��ȣ�*/                                                        
		  for(j=1;j<=m;j++)  
			     if(zhl[j].p1==i&&zhl[j].p2!=0)  
				 { 
					 if(zhl[j].kx==1)
					 {   
			 	        mozhi(zhl[j].r,zhl[j].x);
				        if(mo==0)  continue;
	                    shang(1,0,zhl[j].r,zhl[j].x); 
	                    G[i][i]+=c2;
	                    B[i][i]+=d2;
					 }
					 else 
					 {
						mozhi(zhl[j].r,zhl[j].x);
				        if(mo==0)  continue;
	                    shang(1,0,zhl[j].r,zhl[j].x); 
	                    G[i][i]+=c2/zhl[j].kx+c2*(1-zhl[j].kx)/(zhl[j].kx*zhl[j].kx);
	                    B[i][i]+=d2/zhl[j].kx+d2*(1-zhl[j].kx)/(zhl[j].kx*zhl[j].kx);
					 }

				}
				else if(zhl[j].p2==i)
				{ 
					 if(zhl[j].kx==1)
					 {   
			 	        mozhi(zhl[j].r,zhl[j].x);
				        if(mo==0)  continue;
	                    shang(1,0,zhl[j].r,zhl[j].x); 
	                    G[i][i]+=c2;
	                    B[i][i]+=d2;
					 }
					 else 
					 {
						mozhi(zhl[j].r,zhl[j].x);
				        if(mo==0)  continue;
	                    shang(1,0,zhl[j].r,zhl[j].x); 
	                    G[i][i]+=c2/zhl[j].kx+c2*(zhl[j].kx-1)/zhl[j].kx;
	                    B[i][i]+=d2/zhl[j].kx+d2*(zhl[j].kx-1)/zhl[j].kx;
					 }

				}
			
     for(k=1;k<=m;k++)                              /*�ڵ㵼�ɾ�������Խ����ϣ����ǷǱ�׼��ȣ���Ԫ��*/
		 if(zhl[k].kx==1)
		 {  
		    i=zhl[k].p1;
	        j=zhl[k].p2;
	        mozhi(zhl[k].r,zhl[k].x);
            if(mo==0)  continue;
            shang(1,0,zhl[k].r,zhl[k].x); 
	        G[i][j]-=c2;
	        B[i][j]-=d2;
	        G[j][i]=G[i][j];
	        B[j][i]=B[i][j];
		 }
		 else
		 {
			i=zhl[k].p1;
	        j=zhl[k].p2;
	        mozhi(zhl[k].r,zhl[k].x);
            if(mo==0)  continue;
            shang(1,0,zhl[k].r,zhl[k].x); 
	        G[i][j]-=c2/zhl[k].kx;
	        B[i][j]-=d2/zhl[k].kx;
	        G[j][i]=G[i][j];
	        B[j][i]=B[i][j];
		 }


/*--------------------------����ڵ㵼�ɾ���------------------------------*/
  fprintf(fp2,"\n\n                         ********* ����������� *********\n");
  fprintf(fp2,"\n  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
  fprintf(fp2,"\n     �ڵ㵼�ɾ���Ϊ:");
  for(i=1;i<=n;i++)
  { 
	  fprintf(fp2,"\n     ");
      for(k=1;k<=n;k++)
	  {
		  fprintf(fp2,"%f",G[i][k]);
          if(B[i][k]>=0)
		  { 
			  fprintf(fp2,"+j");
              fprintf(fp2,"%f    ",B[i][k]); 
		  }
	      else
		  { 
			  B[i][k]=-B[i][k];
	          fprintf(fp2,"-j");
              fprintf(fp2,"%f    ",B[i][k]); 
              B[i][k]=-B[i][k];
		  }
	  }
  }
  fprintf(fp2,"\n  ------------------------------------------------------------------------------\n");
 }

/*----------------------------------ţ��--����ѷ���������----------------------------------*/
void Calculate_Unbalanced_Para()
{
	for(i=1;i<=n;i++)                       /*����PQ�ڵ㲻ƽ����*/
	{
		if(jd[i].s==1)
		{
			t=jd[i].num;
		    CC[t]=DD[t]=0;
		    for(j=1;j<=n;j++)
			{
				for(a=1;a<=n;a++)		  
				{
					if(jd[a].num==j)
					    break; 
				}                                         
			    ji(G[t][j],-B[t][j],jd[a].e,-jd[a].f);
			    CC[t]+=c1;
				DD[t]+=d1;                  
			}	                                    
				ji(jd[i].e,jd[i].f,CC[t],DD[t]);
				jd[i].dp=jd[i].p-c1;
				jd[i].dq=jd[i].q-d1;      
		}
		if(jd[i].s==2)                      /*����PV�ڵ㲻ƽ����*/
		{
			t=jd[i].num;
		    CC[t]=DD[t]=0;
		    for(j=1;j<=n;j++)
			{
				for(a=1;a<=n;a++)		  
				{
					if(jd[a].num==j)
					    break; 
				}                                         
			    ji(G[t][j],-B[t][j],jd[a].e,-jd[a].f);
			    CC[t]+=c1;
				DD[t]+=d1;                  
			}	                                    
				ji(jd[i].e,jd[i].f,CC[t],DD[t]);
				jd[i].dp=jd[i].p-c1;
				jd[i].q=d1;
				jd[i].du=jd[i].U*jd[i].U-(jd[i].e*jd[i].e+jd[i].f*jd[i].f);    
		}
	}   
    for(i=1;i<=pq;i++)                                   /*�γɲ�ƽ��������D[M]*/
    {   		
		D[2*i-1]=jd[i].dp;
	    D[2*i]=jd[i].dq; 
	}
    for(i=pq+1;i<=g;i++)
    {  
		D[2*i-1]=jd[i].dp;
	    D[2*i]=jd[i].du; 
	}
	fprintf(fp2,"\n     ��ƽ����Ϊ:");
	for(i=1;i<=pq;i++)
	{	
		t=jd[i].num;
		fprintf(fp2,"\n     dp[%d]=%f",i,D[2*t-1]);
        fprintf(fp2,"\n     dq[%d]=%f",i,D[2*t]);
	} 
	for(i=pq+1;i<=g;i++)
	{	
		t=jd[i].num;
		fprintf(fp2,"\n     dp[%d]=%f",i,D[2*t-1]);
		fprintf(fp2,"\n     du[%d]=%f",i,D[2*t]);
	} 
}     
void Form_Jacobi_Matric()           /*�γ��ſ˱Ⱦ���*/
{ 
	for(i=1;i<=pq;i++)            /*�γ�pq�ڵ�����*/ 
		for(j=1;j<n;j++)
		{  
			int i1=jd[i].num;
	        int j1=jd[j].num;
	        double ei=jd[i].e;
	        double ej=jd[j].e;
	        double fi=jd[i].f;
	        double fj=jd[j].f;
	 
		    if(i!=j)                                              /*��i!=jʱ��H��N��J��L*/
			{ 
			    ykb[2*i-1][2*j-1]=-B[i1][j1]*ei+G[i1][j1]*fi;      /* H */
	            ykb[2*i-1][2*j]=G[i1][j1]*ei+B[i1][j1]*fi;         /* N */
	            ykb[2*i][2*j-1]=-G[i1][j1]*ei-B[i1][j1]*fi;        /* J */
	            ykb[2*i][2*j]=-B[i1][j1]*ei+G[i1][j1]*fi;          /* L */
			}
		    else                                                   /*��i=jʱ��H��N��J��L*/
			{ 
			    AA[i]=0;BB[i]=0;
	            for(k=1;k<=n;k++)
				{   
				    int k1=jd[k].num;
				    ji(G[i1][k1],B[i1][k1],jd[k].e,jd[k].f);				   
		            AA[i]=AA[i]+c1;
		            BB[i]=BB[i]+d1;
				}
	            ykb[2*i-1][2*j-1]=-B[i1][i1]*ei+G[i1][i1]*fi+BB[i];      /*H*/
	            ykb[2*i-1][2*j]=G[i1][i1]*ei+B[i1][i1]*fi+AA[i];         /*N*/
	            ykb[2*i][2*j-1]=-G[i1][i1]*ei-B[i1][i1]*fi+AA[i];        /*J*/
	            ykb[2*i][2*j]=-B[i1][i1]*ei+G[i1][i1]*fi-BB[i];          /*L*/
			}
		}

   for(i=pq+1;i<=g;i++)                                        /*�γ�pv�ڵ�����*/
      for(j=1;j<n;j++)
	  { 
		  int i1=jd[i].num;
	      int j1=jd[j].num;
	      double ei=jd[i].e;
	      double ej=jd[j].e;
	      double fi=jd[i].f;
	      double fj=jd[j].f;
	      if(i!=j)                                           /*��i!=jʱ��H��N*/                                          
		  { 
			  ykb[2*i-1][2*j-1]=-B[i1][j1]*ei+G[i1][j1]*fi;     /*H*/
	          ykb[2*i-1][2*j]=G[i1][j1]*ei+B[i1][j1]*fi;        /*N*/
			  ykb[2*i][2*j-1]=ykb[2*i][2*j]=0;                  /*R��S*/
		  }
	  
	      else                                               /*��i=jʱ��H��N��R��S*/
		  { 
			   AA[i]=0;BB[i]=0;
	           for(k=1;k<=n;k++)
			   {   
				   int k1=jd[k].num;
				   ji(G[i1][k1],B[i1][k1],jd[k].e,jd[k].f);				   
		           AA[i]=AA[i]+c1;
		           BB[i]=BB[i]+d1;
			   }
	           ykb[2*i-1][2*j-1]=-B[i1][i1]*ei+G[i1][i1]*fi+BB[i];      /*H*/
	           ykb[2*i-1][2*j]=G[i1][i1]*ei+B[i1][i1]*fi+AA[i];         /*N*/
	           ykb[2*i][2*j-1]=2*fi;                                /*R*/
	           ykb[2*i][2*j]=2*ei;                                  /*S*/
	      }
	 }
	/*------------------------------����ſ˱Ⱦ���--------------------------------*/ 
    fprintf(fp2,"\n\n     �ſ˱Ⱦ���Ϊ: "); 
	for(i=1;i<=2*g;i++)                                      
	{	
        fprintf(fp2,"\n"); 
		for(j=1;j<=2*g;j++)
		{
			fprintf(fp2,"     %f",ykb[i][j]); 
		}
	} 
}



void Solve_Equations()                              /* ������������� (������Ԫ��ȥ��)*/                                       
 { 
	for(i=1;i<=2*g;i++)                             /*�Ѻ����������������������*/
		ykb[i][2*g+1]=D[i];
	
	k=1;
    do
    {
		rr=ykb[k][k];
        l=k;
        i=k+1;
        do
		{
			if(fabs(ykb[i][k])>fabs(rr))                  /*��ѡ��Ԫ*/
			{ 
				rr=ykb[i][k];
				l=i;
			}
            i++;
		} while(i<=2*g);
        if(l!=k)
		{  
			for(j=k;j<=2*g+1;j++)
			{ 
			   tt=ykb[l][j];
	           ykb[l][j]=ykb[k][j];
	           ykb[k][j]=t;
			}
		}
        for(j=k+1;j<=2*g+1;j++)                           /*��Ԫ*/
        ykb[k][j]/=ykb[k][k];
        for(i=k+1;i<=2*g;i++)
        for(j=k+1;j<=2*g+1;j++)
	    ykb[i][j]-=ykb[i][k]*ykb[k][j];
        k++;
	}  while(k<=2*g);
    
	if(k!=1)
    {
		for(i=2*g;i>=1;i--)                               /*�ش�*/
		{ 
			tt=0;
            for(j=i+1;j<=2*g;j++)
	        tt+=ykb[i][j]*D[j];
            D[i]=ykb[i][2*g+1]-tt;
        }
	}

    for(i=1;i<=g;i++)
    { 
		jd[i].e+=D[2*i];
        jd[i].f+=D[2*i-1];
	}
    max=fabs(D[1]);
    for(i=1;i<=2*(pq+pv);i++)
		if(fabs(D[i])>max)
			max=fabs(D[i]);

}

void Niudun_Lafuxun()
{    
	 int z=1;     
	 fprintf(fp2,"\n          ******************ţ��--����ѷ�������������:***************\n");
	 g=pq+pv;  
     do
	 {    max=1;		 
		  if((z<N)&&(max>=eps))
         {
			 fprintf(fp2,"\n     ��������:  %d\n",z);
		 }
         
		 Calculate_Unbalanced_Para();
		 Form_Jacobi_Matric();
		 Solve_Equations();
		
		 
        fprintf(fp2,"\n\n     ���  df,de: ");
        for(c=1;c<=n;c++)
		{
			for(a=1;a<=n;a++)		  
			{
				if(jd[a].num==c)
					break; 
			}   
			fprintf(fp2,"\n");
            fprintf(fp2,"     �ڵ�Ϊ %2d   df=%8.5f    de=%8.5f",c,D[2*a-1],D[2*a]);
		}
		fprintf(fp2,"\n\n     ������������еĵ�ѹֵ: ");
        for(c=1;c<=n;c++)
		{
			for(a=1;a<=n;a++)		  
			{
				if(jd[a].num==c)
					break; 
			}   
			fprintf(fp2,"\n     U[%d]=%f",c,jd[a].e);
			if(jd[a].f>=0)
				fprintf(fp2,"+j%f",jd[a].f);
			
			else
				fprintf(fp2,"-j%f",-jd[a].f);
		}
		fprintf(fp2,"\n\n  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		 z++;
	 } while((z<N)&&(max>=eps));
  
 }

void Powerflow_Result()
{
	int n1=jd[n].num;
	fprintf(fp2,"\n\n  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
	fprintf(fp2,"                         ******����������******");
	fprintf(fp2,"\n\n  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
	fprintf(fp2,"\n     ���ڵ��ѹֵ: ");
        for(c=1;c<=n;c++)
		{
			for(a=1;a<=n;a++)		  
			{
				if(jd[a].num==c)
					break; 
			}   
			fprintf(fp2,"\n     U[%d]=%f",c,jd[a].e);
			if(jd[a].f>=0)
				fprintf(fp2,"+j%f",jd[a].f);			
			else
				fprintf(fp2,"-j%f",-jd[a].f);
		}
	
	rr=tt=0;	
	for(i=1;i<=n;i++)
	{
		int i1=jd[i].num;
		ji(G[n1][i1],-B[n1][i1],jd[i].e,-jd[i].f);
		rr+=c1;
		tt+=d1;
	}
	ji(jd[n].e,jd[n].f,rr,tt);
	
	fprintf(fp2,"\n\n     ���ڵ�ע�빦��:\n");
  for(i=1;i<=pq;i++)
  { 
	  int i1=jd[i].num;
	  fprintf(fp2,"     PQ�ڵ�:     �ڵ�%d     S[%d]=%f",  i1,i1,jd[i].p);
	  if(jd[i].q>=0)
	  fprintf(fp2,"+j%f\n",jd[i].q);
	  else
	  fprintf(fp2,"-j%f\n",-jd[i].q);
  }
  for(i=pq+1;i<=g;i++)
  { 
	  int i1=jd[i].num;
	  fprintf(fp2,"     PV�ڵ�:     �ڵ�%d     S[%d]=%f",  i1,i1,jd[i].p);
	  if(jd[i].q>=0)
	  fprintf(fp2,"+j%f\n",jd[i].q);
	  else
	  fprintf(fp2,"-j%f\n",-jd[i].q);
  }
  
  fprintf(fp2,"     ƽ��ڵ�:   �ڵ�%d",jd[n].num,jd[n].num);
  fprintf(fp2,"     S[%d]=%f",n1,c1);
	if(d1>=0)
		fprintf(fp2,"+j%f",d1);
	else
	    fprintf(fp2,"-j%f",-d1);

	fprintf(fp2,"\n\n     ��·����:\n");
	rr=tt=0;
    for(i=1;i<=m;i++)
	{
		int i1=zhl[i].p1;
		int j1=zhl[i].p2;
		AA[i]=BB[i]=0;
		for(a=1;a<=n;a++)			  
		{
			if(jd[a].num==i1)
				break;
		} 
		for(b=1;b<=n;b++)			  
		{
			if(jd[b].num==j1)
				break;
		}
		mozhi(zhl[i].r,zhl[i].x);
		if(mo==0)
			continue;
		shang(1,0,zhl[i].r,zhl[i].x);
		ji(jd[a].e-jd[b].e,-jd[a].f+jd[b].f,c2,-d2);
		ji(jd[a].e,jd[a].f,c1,d1);
		fprintf(fp2,"     ��·%d: %d--%d �Ĺ���Ϊ:   %f",i,i1,j1,c1);
		if(d1>=0)
			fprintf(fp2,"+j%f\n",d1);
	    else
	        fprintf(fp2,"-j%f\n",-d1);
		AA[i]+=c1;
		BB[i]+=d1;
		ji(jd[b].e-jd[a].e,-jd[b].f+jd[a].f,c2,-d2);
		ji(jd[b].e,jd[b].f,c1,d1);
		fprintf(fp2,"     ��·%d: %d--%d �Ĺ���Ϊ:   %f",i,j1,i1,c1);
		if(d1>=0)
			fprintf(fp2,"+j%f\n",d1);
	    else
	        fprintf(fp2,"-j%f\n",-d1);
        AA[i]+=c1;
		BB[i]+=d1;
		rr+=AA[i];
		tt+=BB[i];

	} 
    fprintf(fp2,"\n\n     ��·��Ĺ���:\n");
	for(i=1;i<=m;i++)
	{
		int i1=zhl[i].p1;
		int j1=zhl[i].p2;
	    fprintf(fp2,"     ��·%d��ĵĹ���Ϊ:   %f",i,AA[i]);
		if(BB[i]>=0)
			fprintf(fp2,"+j%f\n",BB[i]);
	    else
			fprintf(fp2,"-j%f\n",-BB[i]);
	}
			
	fprintf(fp2,"\n\n     ��������Ĺ���Ϊ:   %f",rr);
		if(tt>=0)
			fprintf(fp2,"+j%f\n",tt);
	    else
	        fprintf(fp2,"-j%f\n",-tt);
	fprintf(fp2,"\n ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");	
    fprintf(fp2,"\n\n                   ********* ����������� *********");
}

void main()
{
	 
	 data();                                /*��ȡ����*/
     Form_Y();                             /*�γɽڵ㵼�ɾ���*/
	 for(i=1;i<=pq;i++)                      /* e��f����ֵ*/  
	 { 
		 jd[i].e=1;  jd[i].f=0;	
	 }
     for(i=pq+1;i<n;i++)
	 {	  
		 jd[i].e=jd[i].U;  jd[i].f=0;
	 }                            
	 Niudun_Lafuxun();                      /*ţ��--����ѷ����*/
	 Powerflow_Result();                    /*�������������*/
	 printf("\n********����������ɣ�����output.txt�ļ��в鿴���********\n\n");
	
 }
